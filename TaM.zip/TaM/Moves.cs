﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaM {
    public class Moves {
        public static Directions UP = Directions.UP;
        public static Directions DOWN = Directions.DOWN;
        public static Directions LEFT = Directions.LEFT;
        public static Directions RIGHT = Directions.RIGHT;
        public static Directions PAUSE = Directions.PAUSE;

    }

}

